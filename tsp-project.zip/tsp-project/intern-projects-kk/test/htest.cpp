#include <gtest/gtest.h>
#include "C:\Users\kaan.karacanta\source\repos\intern-projects-kk\intern-projects-kk\headers\Node.h"
#include "C:\Users\kaan.karacanta\source\repos\intern-projects-kk\intern-projects-kk\headers\StaticArray.h"
#include "C:\Users\kaan.karacanta\source\repos\intern-projects-kk\intern-projects-kk\headers\StaticDoublyLinkedList.h"

TEST(case1, LL) 
{
	StaticDoublyLinkedList<double> list;
    list.insert(10.5);
	list.insert(20.7);
	list.insert(30.2);
	list.insert(40.1);
	list.insert(50.9);
	list.display(); // Output: 10.5 20.7 30.2 40.1 50.9

	double testElement0 = list.find(10.5)->data;
	double testElement1 = list.find(20.7)->data;
	double testElement2 = list.find(30.2)->data;
	double testElement3 = list.find(40.1)->data;
	double testElement4 = list.find(50.9)->data;

	EXPECT_EQ(10.5, testElement0);
	EXPECT_TRUE(true);

	EXPECT_EQ(20.7, testElement1);
	EXPECT_TRUE(true);

	EXPECT_EQ(30.2, testElement2);
	EXPECT_TRUE(true);

	EXPECT_EQ(40.1, testElement3);
	EXPECT_TRUE(true);

	EXPECT_EQ(50.9, testElement4);
	EXPECT_TRUE(true);
}

TEST(case2, LL)
{
	StaticDoublyLinkedList<double> list;
	list.insert(10.5);
	list.insert(20.7);
	list.insert(30.2);
	list.insert(40.1);
	list.insert(50.9);
	// list.display(); // Output: 10.5 20.7 30.2 40.1 50.9

	list.remove(30.2);
	list.display(); // Output: 10.5 20.7 40.1 50.9

	double testElement0 = list.find(10.5)->data;
	double testElement1 = list.find(20.7)->data;
	double testElement2 = list.find(40.1)->data;
	double testElement3 = list.find(50.9)->data;

	EXPECT_EQ(10.5, testElement0);
	EXPECT_TRUE(true);

	EXPECT_EQ(20.7, testElement1);
	EXPECT_TRUE(true);

	EXPECT_EQ(40.1, testElement2);
	EXPECT_TRUE(true);

	EXPECT_EQ(50.9, testElement3);
	EXPECT_TRUE(true);
}

TEST(case3, LL)
{
	StaticDoublyLinkedList<double> list;
	list.insert(10.5);
	list.insert(20.7);
	list.insert(30.2);
	list.insert(40.1);
	list.insert(50.9);
	// list.display(); // Output: 10.5 20.7 30.2 40.1 50.9

	list.remove(30.2);
	// list.display(); // Output: 10.5 20.7 40.1 50.9

	list.updateElement(20.7, 20.8);
	list.display(); // Output: 10.5 20.8 40.1 50.9

	double testElement0 = list.find(10.5)->data;
	double testElement1 = list.find(20.8)->data;
	double testElement2 = list.find(40.1)->data;
	double testElement3 = list.find(50.9)->data;

	EXPECT_EQ(10.5, testElement0);
	EXPECT_TRUE(true);

	EXPECT_EQ(20.8, testElement1);
	EXPECT_TRUE(true);

	EXPECT_EQ(40.1, testElement2);
	EXPECT_TRUE(true);

	EXPECT_EQ(50.9, testElement3);
	EXPECT_TRUE(true);
}

TEST(case4, LL)
{
	StaticDoublyLinkedList<double> list;
	list.insert(10.5);
	list.insert(20.7);
	list.insert(30.2);
	list.insert(40.1);
	list.insert(50.9);
	// list.display(); // Output: 10.5 20.7 30.2 40.1 50.9

	list.remove(30.2);
	// list.display(); // Output: 10.5 20.7 40.1 50.9

	list.updateElement(20.7, 20.8);
	// list.display(); // Output: 10.5 20.8 40.1 50.9

	list.remove(10.5);
	list.display(); // Output: 20.8 40.1 50.9

	double testElement0 = list.find(20.8)->data;
	double testElement1 = list.find(40.1)->data;
	double testElement2 = list.find(50.9)->data;

	EXPECT_EQ(20.8, testElement0);
	EXPECT_TRUE(true);

	EXPECT_EQ(40.1, testElement1);
	EXPECT_TRUE(true);

	EXPECT_EQ(50.9, testElement2);
	EXPECT_TRUE(true);
}

TEST(case5, LL)
{
    StaticDoublyLinkedList<double> list;
	list.insert(10.5);
	list.insert(20.7);
	list.insert(30.2);
	list.insert(40.1);
	list.insert(50.9);
	// list.display(); // Output: 10.5 20.7 30.2 40.1 50.9

	list.remove(30.2);
	// list.display(); // Output: 10.5 20.7 40.1 50.9

	list.updateElement(20.7, 20.8);
	// list.display(); // Output: 10.5 20.8 40.1 50.9

	list.remove(10.5);
	// list.display(); // Output: 20.8 40.1 50.9

	list.remove(50.9);
	list.display(); // Output: 20.8 40.1

	double testElement0 = list.find(20.8)->data;
	double testElement1 = list.find(40.1)->data;

	EXPECT_EQ(20.8, testElement0);
	EXPECT_TRUE(true);

	EXPECT_EQ(40.1, testElement1);
	EXPECT_TRUE(true);
}

TEST(case6, ARR)
{
	StaticArray<int> array;

	array.insert(10);
	array.insert(20);
	array.insert(30);
	array.insert(40);
	array.insert(50);
	array.insert(60);
	array.insert(70);
	array.display(); // Output: 10 20 30 40 50 60 70

	int testEle0 = array.find(10);
	int testEle1 = array.find(20);
	int testEle2 = array.find(30);
	int testEle3 = array.find(40);
	int testEle4 = array.find(50);
	int testEle5 = array.find(60);
	int testEle6 = array.find(70);

	EXPECT_EQ(0, testEle0);
	EXPECT_TRUE(true);

	EXPECT_EQ(1, testEle1);
	EXPECT_TRUE(true);

	EXPECT_EQ(2, testEle2);
	EXPECT_TRUE(true);

	EXPECT_EQ(3, testEle3);
	EXPECT_TRUE(true);

	EXPECT_EQ(4, testEle4);
	EXPECT_TRUE(true);

	EXPECT_EQ(5, testEle5);
	EXPECT_TRUE(true);

	EXPECT_EQ(6, testEle6);
	EXPECT_TRUE(true);
}

TEST(case7, ARR)
{
	StaticArray<int> array;

	array.insert(10);
	array.insert(20);
	array.insert(30);
	array.insert(40);
	array.insert(50);
	array.insert(60);
	array.insert(70);
	// array.display(); // Output: 10 20 30 40 50 60 70

	array.pop();
	array.display(); // Output: 10 20 30 40 50 60

	int testEle0 = array.find(10);
	int testEle1 = array.find(20);
	int testEle2 = array.find(30);
	int testEle3 = array.find(40);
	int testEle4 = array.find(50);
	int testEle5 = array.find(60);

	EXPECT_EQ(0, testEle0);
	EXPECT_TRUE(true);

	EXPECT_EQ(1, testEle1);
	EXPECT_TRUE(true);

	EXPECT_EQ(2, testEle2);
	EXPECT_TRUE(true);

	EXPECT_EQ(3, testEle3);
	EXPECT_TRUE(true);

	EXPECT_EQ(4, testEle4);
	EXPECT_TRUE(true);

	EXPECT_EQ(5, testEle5);
	EXPECT_TRUE(true);
}

TEST(case8, ARR)
{
	StaticArray<int> array;

	array.insert(10);
	array.insert(20);
	array.insert(30);
	array.insert(40);
	array.insert(50);
	array.insert(60);
	array.insert(70);
	// array.display(); // Output: 10 20 30 40 50 60 70

	array.pop();
	// array.display(); // Output: 10 20 30 40 50 60

	array.remove(30);
	array.display(); // Output: 10 20 40 50 60

	int testEle0 = array.find(10);
	int testEle1 = array.find(20);
	int testEle2 = array.find(40);
	int testEle3 = array.find(50);
	int testEle4 = array.find(60);

	EXPECT_EQ(0, testEle0);
	EXPECT_TRUE(true);

	EXPECT_EQ(1, testEle1);
	EXPECT_TRUE(true);

	EXPECT_EQ(2, testEle2);
	EXPECT_TRUE(true);

	EXPECT_EQ(3, testEle3);
	EXPECT_TRUE(true);

	EXPECT_EQ(4, testEle4);
	EXPECT_TRUE(true);
}

TEST(case9, ARR)
{
	StaticArray<int> array;

	array.insert(10);
	array.insert(20);
	array.insert(30);
	array.insert(40);
	array.insert(50);
	array.insert(60);
	array.insert(70);
	// array.display(); // Output: 10 20 30 40 50 60 70

	array.pop();
	// array.display(); // Output: 10 20 30 40 50 60

	array.remove(30);
	// array.display(); // Output: 10 20 40 50 60

	array.remove(10);
	array.display(); // Output: 20 40 50 60

	int testEle0 = array.find(20);
	int testEle1 = array.find(40);
	int testEle2 = array.find(50);
	int testEle3 = array.find(60);

	EXPECT_EQ(0, testEle0);
	EXPECT_TRUE(true);

	EXPECT_EQ(1, testEle1);
	EXPECT_TRUE(true);

	EXPECT_EQ(2, testEle2);
	EXPECT_TRUE(true);

	EXPECT_EQ(3, testEle3);
	EXPECT_TRUE(true);
}

TEST(case10, ARR)
{
	StaticArray<int> array;

	array.insert(10);
	array.insert(20);
	array.insert(30);
	array.insert(40);
	array.insert(50);
	array.insert(60);
	array.insert(70);
	// array.display(); // Output: 10 20 30 40 50 60 70

	array.pop();
	// array.display(); // Output: 10 20 30 40 50 60

	array.remove(30);
	// array.display(); // Output: 10 20 40 50 60

	array.remove(10);
	// array.display(); // Output: 20 40 50 60

	array.remove(60);
	array.display(); // Output: 20 40 50

	int testEle0 = array.find(20);
	int testEle1 = array.find(40);
	int testEle2 = array.find(50);

	EXPECT_EQ(0, testEle0);
	EXPECT_TRUE(true);

	EXPECT_EQ(1, testEle1);
	EXPECT_TRUE(true);

	EXPECT_EQ(2, testEle2);
	EXPECT_TRUE(true);
}

TEST(case11, ARR)
{
	StaticArray<int> array;

	array.insert(10);
	array.insert(20);
	array.insert(30);
	array.insert(40);
	array.insert(50);
	array.insert(60);
	array.insert(70);
	// array.display(); // Output: 10 20 30 40 50 60 70

	array.pop();
	// array.display(); // Output: 10 20 30 40 50 60

	array.remove(30);
	// array.display(); // Output: 10 20 40 50 60

	array.remove(10);
	// array.display(); // Output: 20 40 50 60

	array.remove(60);
	// array.display(); // Output: 20 40 50

	array.updateElement(0, 30);
	array.display(); // Output: 30 40 50

	int testEle0 = array.find(30);
	int testEle1 = array.find(40);
	int testEle2 = array.find(50);

	EXPECT_EQ(0, testEle0);
	EXPECT_TRUE(true);

	EXPECT_EQ(1, testEle1);
	EXPECT_TRUE(true);

	EXPECT_EQ(2, testEle2);
	EXPECT_TRUE(true);
}

TEST(case12, ARR)
{
	StaticArray<int> array;

	array.insert(10);
	array.insert(20);
	array.insert(30);
	array.insert(40);
	array.insert(50);
	array.insert(60);
	array.insert(70);
	// array.display(); // Output: 10 20 30 40 50 60 70

	array.pop();
	// array.display(); // Output: 10 20 30 40 50 60

	array.remove(30);
	// array.display(); // Output: 10 20 40 50 60

	array.remove(10);
	// array.display(); // Output: 20 40 50 60

	array.remove(60);
	// array.display(); // Output: 20 40 50

	array.updateElement(0, 30);
	// array.display(); // Output: 30 40 50

	array.updateElement(2, 60);
	array.display(); // Output: 30 40 60

	int testEle0 = array.find(30);
	int testEle1 = array.find(40);
	int testEle2 = array.find(60);

	EXPECT_EQ(0, testEle0);
	EXPECT_TRUE(true);

	EXPECT_EQ(1, testEle1);
	EXPECT_TRUE(true);

	EXPECT_EQ(2, testEle2);
	EXPECT_TRUE(true);
}