#pragma once
#ifndef STATIC_ARRAY_H
#define STATIC_ARRAY_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include "Node.h"
#include "StaticDoublyLinkedList.h"

using namespace std;

#define MAX_SIZE 81

template <typename T>
class StaticArray
{
private:

public:
    T data[MAX_SIZE];
    int lastIndex;

    StaticArray()
    {
        for (int i = 0; i < MAX_SIZE; ++i)
        {
            data[i] = T(); // Default initialization for type T
        }
        lastIndex = -1;
    }

    void insert(const T& value)
    {
        if (lastIndex == MAX_SIZE - 1)
        {
            printf("Array is full\n");
            return;
        }
        else
        {
            data[++lastIndex] = value;
            return;
        }
    }

    void pop()
    {
        if (lastIndex == -1)
        {
            printf("Array is empty\n");
            return;
        }
        else
        {
            this->data[lastIndex--] = 0;
            return;
        }
    }

    void remove(const T& value)
    {
        if (lastIndex == -1)
        {
            printf("Array is empty\n");
            return;
        }
        else
        {
            int index = -1;
            for (int i = 0; i <= lastIndex; ++i)
            {
                if (data[i] == value)
                {
                    index = i;
                    break;
                }
            }
            if (index == -1)
            {
                printf("Value not found\n");
                return;
            }
            else
            {
                for (int i = index; i < lastIndex; ++i)
                {
                    data[i] = data[i + 1];
                }
                this->data[lastIndex--] = 0;
                return;
            }
        }
    }

    int find(const T& value)
    {
        if (lastIndex == -1)
        {
            printf("Array is empty\n");
            return -1;
        }
        else
        {
            for (int i = 0; i <= lastIndex; ++i)
            {
                if (data[i] == value)
                {
                    return i;
                }
            }
            printf("Value not found\n");
            return -1;
        }
    }

    void updateElement(int index, const T& newValue)
    {
        if (index < 0 || index > lastIndex)
        {
            printf("Invalid index\n");
            return;
        }
        else
        {
            data[index] = newValue;
            return;
        }
    }

    void display()
    {
        if (lastIndex == -1)
        {
            printf("Array is empty\n");
            return;
        }
        else
        {
            for (int i = 0; i <= lastIndex; ++i)
            {
                cout << data[i] << " ";
            }
            cout << endl;
            return;
        }
    }

    int size()
    {
        return lastIndex;
    }
};

#endif // STATIC_ARRAY_H
