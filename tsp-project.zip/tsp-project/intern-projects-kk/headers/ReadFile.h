#pragma once
#ifndef READ_FILE_H 
#define READ_FILE_H

#include <vector>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <filesystem>
#include "../headers/ReadFile.h"
#include "../headers/StaticArray.h"
#include "../headers/StaticDoublyLinkedList.h"

void my_read_file(std::vector<std::vector<int>>& data);

void vector_to_array(std::vector<std::vector<int>>& data, StaticArray<StaticArray<int>>& arr);

#endif // READ_FILE_H
