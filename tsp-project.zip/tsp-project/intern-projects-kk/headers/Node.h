#pragma once
#ifndef NODE_H
#define NODE_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

template <typename T>
class Node
{
public:
    T data;
    Node<T>* next;
    Node<T>* prev;

    Node() : data(0), next(nullptr), prev(nullptr) {}
    Node(const T& value) : data(value), next(nullptr), prev(nullptr) {}
    Node(const T& value, Node<T>* nextNode, Node<T>* prevNode) : data(value), next(nextNode), prev(prevNode) {}
};

#endif // NODE_H
