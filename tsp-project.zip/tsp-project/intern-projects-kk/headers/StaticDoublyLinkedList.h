#pragma once
#ifndef STATIC_DOUBLY_LINKED_LIST_H
#define STATIC_DOUBLY_LINKED_LIST_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include "StaticArray.h"
#include "Node.h"

using namespace std;

template <typename T>
class StaticDoublyLinkedList
{
private:
    Node<T>* head;

public:
    StaticDoublyLinkedList() : head(nullptr) {}

    void insert(const T& value)
    {
        if (!head)
        {
            // List is empty, insert at the beginning
            head = new Node<T>(value);
            return;
        }
        else
        {
            // List is not empty, insert at the end
            Node<T>* currentNode = head;
            while (currentNode->next)
            {
                currentNode = currentNode->next;
            }
            currentNode->next = new Node<T>(value, NULL, currentNode);
            return;
        }
    }

    void remove(const T& value)
    {
        if (!head)
        {
            printf("List is empty\n");
            return;
        }
        else
        {
            // List is not empty, remove the first occurrence of the value
            Node<T>* currentNode = head;
            while (currentNode)
            {
                if (currentNode->data == value)
                {
                    // Found the value, remove it
                    if (currentNode->prev)
                    {
                        // Not the first node
                        currentNode->prev->next = currentNode->next;
                    }
                    else
                    {
                        // First node
                        head = currentNode->next;
                    }
                    if (currentNode->next)
                    {
                        // Not the last node
                        currentNode->next->prev = currentNode->prev;
                    }
                    delete currentNode;
                    return;
                }
                currentNode = currentNode->next;
            }
            return;
        }
    }

    Node<T>* find(const T& value)
    {
        if (!head)
        {
            printf("List is empty\n");
            return NULL;
        }
        else
        {
            // List is not empty, find the first occurrence of the value
            Node<T>* currentNode = head;
            while (currentNode)
            {
                if (currentNode->data == value)
                {
                    // Found the value, return it
                    return currentNode;
                }
                currentNode = currentNode->next;
            }
            return NULL;
        }
    }

    void updateElement(const T& oldValue, const T& newValue)
    {
        Node<T>* node = find(oldValue);
        if (node)
        {
            node->data = newValue;
        }
    }

    void display()
    {
        if (!head)
        {
            printf("List is empty\n");
            return;
        }
        else
        {
            // List is not empty, display all elements
            Node<T>* currentNode = head;
            while (currentNode)
            {
                cout << currentNode->data << " ";
                currentNode = currentNode->next;
            }
            cout << endl;
            return;
        }
    }
};

#endif // STATIC_DOUBLY_LINKED_LIST_H
