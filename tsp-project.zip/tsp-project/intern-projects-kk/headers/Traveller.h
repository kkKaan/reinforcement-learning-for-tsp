#ifndef TRAVELLER_H
#define TRAVELLER_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "../headers/StaticDoublyLinkedList.h"
#include "../headers/StaticArray.h"
#include "../headers/Node.h"

// void traveller(std::vector<vector<int>> &distanceMatrix, int &x, int &y, int &travelled, int startingLocation, int &travelled_distance);

StaticArray<int> findAvailableNeighbors(StaticArray<StaticArray<int>>& distanceMatrix, int x, int y, int currentLocation, int* isVisited);

void RL(std::vector<std::vector<int>> distanceMatrix);

#endif // !TRAVELLER_H
