#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include "../headers/StaticDoublyLinkedList.h"
#include "../headers/StaticArray.h"
#include "../headers/Node.h"
#include "../headers/ReadFile.h"
#include "../headers/Traveller.h"

using namespace std;

int main()
{
    vector<vector<int>> data;
    //StaticArray<StaticArray<int>> arr;
    my_read_file(data);
    //vector_to_array(data, arr);

    //unsigned int start_city = 5;

    //// vector<int> isVisited(81, 0);
    //int isVisited[81];
    //for (int i = 0; i < 81; ++i) isVisited[i] = 0;

    //for (int i = 0; i < 81; ++i)
    //{
    //    for (int j = 0; j < 81; ++j)
    //    {
    //        cout << arr.data[i].data[j] << " ";
    //    }
    //    cout << endl;
    //}

    //StaticArray<int> test2 = findAvailableNeighbors(arr, 100, 30, 5, isVisited);
    //cout << test2.size() << endl;
    // vector<int> test1 = findAvailableNeighbors(data, 100, 30, 5, isVisited);
    // printf("%u ", test1.size());

    //int x = 0;
    //int bestX = 0;
    //int y = 0;
    //int bestY = 0;
    //int travelled = 0;
    //int best_city_to_start = 0;
    //int total_dist = 0;
    //int best_dist = 0;

    //for (int i = 0; i < 81; ++i)
    //{
    //    int temp = 0;
    //    traveller(data, x, y, temp, i, total_dist);
    //    if (temp > travelled)
    //    {
    //        best_city_to_start = i;
    //        bestX = x;
    //        bestY = y;
    //        travelled = temp;
    //        best_dist = total_dist;
    //    }
    //    printf("%d - X: %d, Y: %d, visited cities :%d, total distance: %d, average distance: %d \n", i+1, x, y, temp, total_dist, temp * x);
    //}
    //printf("city: %d\nX: %d\nY: %d\nvisited cities: %d\ntotal distance: %d\naverage distance: %d \n", best_city_to_start, bestX, bestY, travelled, best_dist, travelled * bestX);
    //

    RL(data);

    return 0;
}
