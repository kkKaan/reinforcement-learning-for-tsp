#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <filesystem>
#include "../headers/ReadFile.h"
#include "../headers/StaticArray.h"
#include "../headers/StaticDoublyLinkedList.h"

void my_read_file(std::vector<std::vector<int>> &data)
{
    // File pointer
    std::fstream myfile("C:/Users/kaan.karacanta/source/repos/intern-projects-kk/intern-projects-kk/ilmesafe.csv");

    // Open an existing file

    // file.open("ilmesafe.txt");

    if (myfile.fail())
    {
        std::cerr << "Error opening CSV file" << std::endl;
        return;
    }

    std::string line;
    while (std::getline(myfile, line))
    {
        std::vector<int> row;
        std::stringstream lineStream(line);
        std::string cell;

        while (std::getline(lineStream, cell, ';'))
        {
            row.push_back(stoi(cell));
        }

        data.push_back(row);
    }

}

void vector_to_array(std::vector<std::vector<int>> &data, StaticArray<StaticArray<int>> &arr)
{
    for (int i = 0; i < data.size(); ++i)
    {
        for (int j = 0; j < data.size(); ++j)
        {
            arr.data[i].data[j] = data[i][j];
        }
    }
}
